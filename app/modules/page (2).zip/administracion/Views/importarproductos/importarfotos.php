<iframe src="/scripts/tinyfilemanager.php?hash=<?php echo md5("OMEGA"); ?>&p=&upload" width="100%" height="500" frameborder="0">
</iframe>