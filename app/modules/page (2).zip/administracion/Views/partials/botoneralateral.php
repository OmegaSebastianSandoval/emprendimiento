<ul>

<?php if($_SESSION['kt_login_level']=="1" or $_SESSION['kt_login_level']=="2"){ ?>
	<li <?php if($this->botonpanel == 1){ ?>class="activo"<?php } ?>><a href="/administracion/panel"><i class="fas fa-info-circle"></i> Información Página</a></li>
	<li <?php if($this->botonpanel == 2){ ?>class="activo"<?php } ?>><a href="/administracion/publicidad"><i class="far fa-images"></i> Administrar Banner</a></li>
	<li <?php if($this->botonpanel == 3){ ?>class="activo"<?php } ?>><a href="/administracion/contenido"><i class="fas fa-file-invoice"></i> Administrar Contenidos</a></li>
<?php } ?>

<?php if($_SESSION['kt_login_level']=="1" or $_SESSION['kt_login_level']=="3" or $_SESSION['kt_login_level']=="4"){ ?>
	<li <?php if($this->botonpanel == 5){ ?>class="activo"<?php } ?>><a href="/administracion/categorias"><i class="fas fa-file-invoice"></i> Administrar Categorías</a></li>
	<!-- <li <?php if($this->botonpanel == 6){ ?>class="activo"<?php } ?>><a href="/administracion/tiendas"><i class="fas fa-file-invoice"></i> Administrar Tiendas</a></li>
	<li <?php if($this->botonpanel == 6){ ?>class="activo"<?php } ?>><a href="/administracion/productos"><i class="fas fa-file-invoice"></i> Administrar Productos</a></li> -->
<?php } ?>
<!-- <?php if($_SESSION['kt_login_level']=="1" or $_SESSION['kt_login_level']=="3"){ ?>
	<li <?php if($this->botonpanel == 9){ ?>class="activo"<?php } ?>><a href="/administracion/importarproductos/manage/?id=1"><i class="fas fa-file-invoice"></i> Importar Productos</a></li>
	<li <?php if($this->botonpanel == 9){ ?>class="activo"<?php } ?>><a href="/administracion/importarproductos/importarfotos/"><i class="fas fa-file-invoice"></i> Importar Fotos</a></li>
<?php } ?>
<?php if($_SESSION['kt_login_level']=="1" or $_SESSION['kt_login_level']=="3" or $_SESSION['kt_login_level']=="4"){ ?>
	<li <?php if($this->botonpanel == 12){ ?>class="activo"<?php } ?>><a href="/administracion/productos/exportar/?excel=1"><i class="fas fa-file-invoice"></i> Exportar Productos</a></li>
<?php } ?>
<?php if($_SESSION['kt_login_level']=="1" or $_SESSION['kt_login_level']=="4" or $_SESSION['kt_login_level']=="3"){ ?>
	<li <?php if($this->botonpanel == 13){ ?>class="activo"<?php } ?>><a href="/administracion/pedidos/"><i class="fas fa-file-invoice"></i> Pedidos</a></li>
	<li <?php if($this->botonpanel == 14){ ?>class="activo"<?php } ?>><a href="/administracion/pedidos/exportar/"><i class="fas fa-file-invoice"></i>Exportar Pedidos</a></li>
<?php } ?>
<?php if($_SESSION['kt_login_level']=="1" or $_SESSION['kt_login_level']=="3"){ ?>
	<li <?php if($this->botonpanel == 10){ ?>class="activo"<?php } ?>><a href="/administracion/importarsocios/manage/?id=1"><i class="fas fa-file-invoice"></i> Importar Socios</a></li>
<?php } ?>
<?php if($_SESSION['kt_login_level']=="1" or $_SESSION['kt_login_level']=="3" or $_SESSION['kt_login_level']=="4"){ ?>
	<li <?php if($this->botonpanel == 11){ ?>class="activo"<?php } ?>><a href="/administracion/socios/"><i class="fas fa-file-invoice"></i>Socios</a></li>
<?php } ?>
<?php if($_SESSION['kt_login_level']=="1" or $_SESSION['kt_login_level']=="3"){ ?>
	<li <?php if($this->botonpanel == 7){ ?>class="activo"<?php } ?>><a href="/administracion/zonas"><i class="fas fa-map-marked-alt"></i> Zonas domicilios</a></li>
<?php } ?> -->
<?php if($_SESSION['kt_login_level']=="1"){ ?>
	<li <?php if($this->botonpanel == 4){ ?>class="activo"<?php } ?>><a href="/administracion/usuario"><i class="fas fa-users"></i> Administrar Usuarios</a></li>
<?php } ?>
</ul>