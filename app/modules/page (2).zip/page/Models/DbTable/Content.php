<?php 

/**
* 
*/
class Page_Model_DbTable_Content extends Db_Table
{
	protected $_name = 'content';
	protected $_id = 'content_id';
}