<?php 

/**
* 
*/
class Page_Model_DbTable_Productos extends Db_Table
{
	protected $_name = 'productos';
	protected $_id = 'productos_id';
}

