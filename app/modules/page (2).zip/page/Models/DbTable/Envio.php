<?php 

/**
* 
*/
class Page_Model_DbTable_Envio extends Db_Table
{
	protected $_name = 'envio';
	protected $_id = 'envio_id';
}