<?php 

/**
* 
*/
class Page_Model_DbTable_Ciudad extends Db_Table
{
	protected $_name = 'ciudad';
    protected $_id = 'codigo';
}