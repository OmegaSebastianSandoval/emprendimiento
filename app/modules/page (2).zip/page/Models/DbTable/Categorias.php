<?php 

/**
* 
*/
class Page_Model_DbTable_Categorias extends Db_Table
{
	protected $_name = 'categorias';
	protected $_id = 'categorias_id';
}