<?php 

/**
* 
*/
class Page_Model_DbTable_ventasproductocategoria extends Db_Table
{
	protected $_name = 'ventasproducto_categoria';
	protected $_id = 'ventasproducto_categoria_id';
}