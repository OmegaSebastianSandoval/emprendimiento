<?php 

/**
* 
*/
class Page_Model_DbTable_Descuentos extends Db_Table
{
	protected $_name = 'descuentos';
	protected $_id = 'descuentos_id';
}