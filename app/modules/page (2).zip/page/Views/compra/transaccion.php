<div class="titulo-proyecto">
	<h2 class="titulo-principal contact">Carrito de compras</h2>
</div>
<div class="contenidos-productos">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
				<br>
				<h3 class="titulo-verde1">Su pedido ha sido enviado.</h3>
				<br>
            </div>
        </div>
    </div>
</div>