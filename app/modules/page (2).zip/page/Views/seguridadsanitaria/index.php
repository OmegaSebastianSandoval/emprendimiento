<div class="comprar">
    <div class="banner"><?php echo $this->bannersimple; ?></div>
    <?php echo $this->comprar; ?>
</div>