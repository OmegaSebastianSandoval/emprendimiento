<div class="header-content">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 caja-logo">
				<a href="/page/index"><img src="/corte/logo.jpg" class="logo"></a>
			</div>
		</div>
	</div>
</div>