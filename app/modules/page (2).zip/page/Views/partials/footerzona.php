<div class="footer-redes">
	<div class="container">
		<div class="row">
			<div class="col-lg-5 text-left">
				
			</div>
			<div class="col-lg-5 text-left">
			<div class="red1 titulosfooter">

				</div>
				<div class="text-footer">
					<span class="red"></span>
				</div>
			</div>
			<div class="col-lg-2 text-center puntos">
				<div class="row text-center">
					<div align="center" class="col-12">
						<img src="/corte/logo.jpg" style="height: 3.5rem;">
					</div>
			</div>
		</div>
	</div>
</div>
<div class="derechos">
	<span>© 2020</span> Todos los Derechos Reservados Corporación Club El Nogal | Desarrollado por <a href="http://www.omegasolucionesweb.com" target="_blank" class="enlacered1">Omega Soluciones Web</a>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-body">
      	<iframe id="iframe_login" src="/page/login/" width="100%" scrolling="auto" frameborder="0" height="500"></iframe>
      </div>
    </div>
  </div>
</div>