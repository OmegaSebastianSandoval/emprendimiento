<div class="header-redes">
    <div class="container-fluid pestanas-cont">
        <div class="container">
            <div class="row pestanas">
                <div class="col-lg-2 align-self-center">
                    <a href="/page/index"><img src="/corte/logo.jpg" class="logo"></a>
                </div>

                <div class="col-lg-3 col-sm-12 buscar">
                    <form method="post" action="/page/buscar" class="row" id="form-buscar">
                        <div class="col-lg-9 col-md-8 buscar-text">
                            <input type="input" class="form-control" name="buscar" id="buscar"
                              placeholder="Buscar">
                        </div>
                        <div class="col-lg-2 col-md-4 text-right buscar-ico" onclick="$('#buscar_enviar').click();">
                            <i class="fas fa-search" align="right"></i>
                        </div>
                        <div class="d-none"><button type="submit" id="buscar_enviar"></button></div>
                    </form>
                </div>
                <?php if($this->nombre!="") {?>
                <div class="col-lg-7 text-center text-lg-right">
                    <div class="row justify-content-end align-items-center">
                        <div class="nombre">
                            Bienvenido<br> <?php echo $this->nombre; ?>
                        </div>
                        <div class="cuenta">
                            <a href="#" class="btn btn-sm text-white margen_salir">Cuenta</a>
                        </div>
                        <div class="salir">
                            <a href="/page/login/logout" class="btn btn-sm text-white margen_salir">Salir</a>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>

    <div class="container">
        <!--<?php if($this->infopage->info_pagina_telefono) {?>
			<?php $telefono = intval(preg_replace('/[^0-9]+/', '', $this->infopage->info_pagina_telefono), 10);  ?>
			<a href="tel:<?php echo $telefono; ?>" target="_blank" class="red">
				<i class="fas fa-phone"></i>
				<span><?php echo $this->infopage->info_pagina_telefono ?></span>
			</a>
		<?php } ?>
		<?php if($this->infopage->info_pagina_whatsapp) {?>
			<?php $whatsapp = intval(preg_replace('/[^0-9]+/', '', $this->infopage->info_pagina_whatsapp), 10);  ?>
			<a href="https://api.whatsapp.com/send?phone=<?php echo $whatsapp; ?>" target="_blank" class="red" >
				<i class="fab fa-whatsapp"></i>
				<span><?php echo $this->infopage->info_pagina_whatsapp ?></span>
			</a>
		<?php } ?>
		<?php if($this->infopage->info_pagina_facebook) {?>
			<a href="<?php echo $this->infopage->info_pagina_facebook ?>" target="_blank" class="red">
				<i class="fab fa-facebook-f"></i>
			</a>
		<?php } ?>
		<?php if($this->infopage->info_pagina_twitter) {?>
			<a href="<?php echo $this->infopage->info_pagina_twitter ?>" target="_blank" class="red">
				<i class="fab fa-twitter"></i>
			</a>
		<?php } ?>
		<?php if($this->infopage->info_pagina_instagram) {?>
			<a href="<?php echo $this->infopage->info_pagina_instagram ?>" target="_blank" class="red">
				<i class="fab fa-instagram"></i>
			</a>
		<?php } ?>
		<?php if($this->infopage->info_pagina_pinterest) {?>
			<a href="<?php echo $this->infopage->info_pagina_pinterest ?>" target="_blank" class="red">
				<i class="fab fa-pinterest-p"></i>
			</a>
		<?php } ?>
		<?php if($this->infopage->info_pagina_youtube) {?>
			<a href="<?php echo $this->infopage->info_pagina_youtube ?>" target="_blank" class="red">
				<i class="fab fa-youtube"></i>
			</a>
		<?php } ?>
		<?php if($this->infopage->info_pagina_linkdn) {?>
			<a href="<?php echo $this->infopage->info_pagina_linkdn ?>" target="_blank" class="red">
				<i class="fab fa-linkedin-in"></i>
			</a>
		<?php } ?>
		<?php if($this->infopage->info_pagina_google) {?>
			<a href="<?php echo $this->infopage->info_pagina_google ?>" target="_blank" class="red">
				<i class="fab fa-google-plus-g"></i>
			</a>
		<?php } ?>
		<?php if($this->infopage->info_pagina_flickr) {?>
			<a href="<?php echo $this->infopage->info_pagina_flickr ?>" target="_blank" class="red">
				<i class="fab fa-flickr"></i>
			</a>
		<?php } ?>-->

    </div>
</div>
<?php $hora = date("H:i:s"); ?>
<div class="header-content">
    <div class="container">
        <div class="row">

            <div class="col-sm-12 caja-items align-items-center">
                <nav>
                    <ul id="menu2" class="align-self-center">
                        <li><a href="/"><span>Inicio</span></a></li>
                        <li><a href="/page/favoritos"><span>Favoritos</span></a></li>
                        <li><a href="/"><span>Categorías</span></a>
                            <ul>
                                <?php foreach ($this->categorias as $key => $categoria ) { ?>
                                <li><a
                                        href="/page/categoria?id=<?php echo $categoria->categorias_id; ?>&page=1"><?php echo $categoria->categorias_nombre; ?></a>
                                    <?php if(count($categoria->hijos)>0){ ?>
                                    <ul>
                                        <?php foreach ($categoria->hijos as $key2 => $subcategoria): ?>
                                        <li><a
                                                href="?categoria=<?php echo $categoria->categorias_id; ?>&subcategoria=<?php echo $subcategoria->categorias_id; ?>&page=1#a"><?php echo $subcategoria->categorias_nombre; ?></a>
                                        </li>
                                        <?php endforeach ?>
                                    </ul>
                                    <?php } ?>
                                </li>
                                <?php } ?>
                            </ul>
                        </li>
                        <li><a href="/page/entretenimiento"><span>Entretenimiento</span></a></li>
                        <li><a href="/page/comprar"><span>¿Cómo comprar?</span></a></li>
                        <li><a href="/page/formulario"><span>Contacto</span></a></li>

                    </ul>
                </nav>
                <div class="row">
                    <div class="col-4 mt-3"><a class="btn-menu d-block d-sm-block d-md-none"><i class="fas fa-bars"></i></a></div>
                    <div class="col-4 mt-3 img-responsive"><a href="/page/index"><img class="inline-block"
                                src="/corte/logo.jpg" height="50"></a></div>
                </div>
            </div>
        </div>
    </div>

    <!-- <div class="carrito">
		<div class="ver-carrito lateral absolute"></div>
		<div class="carrito-cantidad absolute text-bold circle f-13 text-center cantidad" id="cantidad-total-items"></div>
	</div> -->
</div>

<!--RESPONSIVE-->
<div class="botonera-resposive">
		<div class="row col-12 align-items-center no-gutters py-3">
	<div class="col-8">
		<span class="title-menu-responsive"> Menú</span>
	</div>
	<div class="col-4">
		<a class="btn-menu"><i class="fas fa-times-circle"></i></a>
	</div>
         </div>
		<table class="table table-striped">
			<tbody>
				<tr>
					<td><li class="item"><a href="/" rel="noopener noreferrer">Inicio</a></li></td>
                </tr>
                <tr>
					<td><li class="item"><a href="/page/favoritos"><span>Favoritos</span></a></li></td>
				</tr>
				<tr>
					<td><li class="item">
						<a href="" rel="noopener noreferrer" data-toggle="collapse" data-target="#sub-menu22"><span> Categorías<i class="fas fa-angle-down ml-2"></i></span></a>
							<ul class="sub-menu1 collapse" id="sub-menu22">
							<table class="table table-striped">
							<tbody>
							<?php foreach ($this->categorias as $key => $categoria) {?>	
							<tr><td><li><a
                                                href="/page/categoria?id=<?php echo $categoria->categorias_id; ?>&page=1"><?php echo $categoria->categorias_nombre; ?></a></li></td></tr>
							<?php } ?>
					
							</tbody>
							</table>
							</ul>
						</li> 
					</td>
				</tr>
			
                <tr>
					<td><li class="item"><a href="/page/entretenimiento" rel="noopener noreferrer">Entretenimiento</a></li></td>
				</tr>
			
				<tr>
					<td><li class="item"><a href="/page/formulario"><span> Contacto</span></a></li></li></td>
				</tr>
			
			</tbody>
		</table>
		<div class="col-12 align-self-center">
		<?php if($this->nombre!="") {?>
                <div class="col-lg-7 text-center text-lg-right">
                    <div class="row  align-items-center text-white cuenta-responsive">
                        <div class="col-12">
                            Bienvenido<br> <?php echo $this->nombre; ?>
                        </div>
                        <div class="col-12">
                            <a href="#" class="btn btn-sm text-white ">Cuenta</a>
                        </div>
                        <div class="col-12">
                            <a href="/page/login/logout" class="btn btn-sm text-white ">Salir</a>
                        </div>
                    </div>
                </div>
                <?php } ?>
			<div class="redes-responsive">
				<!--<?php if($this->infopage->info_pagina_telefono) {?>
				<?php $telefono = intval(preg_replace('/[^0-9]+/', '', $this->infopage->info_pagina_telefono), 10);  ?>
				<a href="tel:<?php echo $telefono; ?>" target="_blank" class="red">
					<i class="fas fa-phone"></i>
					<!--<span><?php echo $this->infopage->info_pagina_telefono ?></span>
				</a>
				<?php } ?>
				<?php if($this->infopage->info_pagina_whatsapp) {?>
					<?php $whatsapp = intval(preg_replace('/[^0-9]+/', '', $this->infopage->info_pagina_whatsapp), 10);  ?>
					<a href="https://api.whatsapp.com/send?phone=<?php echo $whatsapp; ?>" target="_blank" class="red" >
						<i class="fab fa-whatsapp"></i>
						<span><?php echo $this->infopage->info_pagina_whatsapp ?></span>
					</a>
				<?php } ?>-->
				<?php if($this->infopage->info_pagina_facebook) {?>
					<a href="<?php echo $this->infopage->info_pagina_facebook ?>" target="_blank" class="red">
						<i class="fab fa-facebook-f"></i>
					</a>
				<?php } ?>
				<?php if($this->infopage->info_pagina_twitter) {?>
					<a href="<?php echo $this->infopage->info_pagina_twitter ?>" target="_blank" class="red">
						<i class="fab fa-twitter"></i>
					</a>
				<?php } ?>
				<?php if($this->infopage->info_pagina_instagram) {?>
					<a href="<?php echo $this->infopage->info_pagina_instagram ?>" target="_blank" class="red">
						<i class="fab fa-instagram"></i>
					</a>
				<?php } ?>
				<?php if($this->infopage->info_pagina_pinterest) {?>
					<a href="<?php echo $this->infopage->info_pagina_pinterest ?>" target="_blank" class="red">
						<i class="fab fa-pinterest-p"></i>
					</a>
				<?php } ?>
				<?php if($this->infopage->info_pagina_youtube) {?>
					<a href="<?php echo $this->infopage->info_pagina_youtube ?>" target="_blank" class="red">
						<i class="fab fa-youtube"></i>
					</a>
				<?php } ?>
				<?php if($this->infopage->info_pagina_linkedin) {?>
					<a href="<?php echo $this->infopage->info_pagina_linkdn ?>" target="_blank" class="red">
						<i class="fab fa-linkedin-in"></i>
					</a>
				<?php } ?>
				<?php if($this->infopage->info_pagina_google) {?>
					<a href="<?php echo $this->infopage->info_pagina_google ?>" target="_blank" class="red">
						<i class="fab fa-google-plus-g"></i>
					</a>
				<?php } ?>
				<?php if($this->infopage->info_pagina_flickr) {?>
					<a href="<?php echo $this->infopage->info_pagina_flickr ?>" target="_blank" class="red">
						<i class="fab fa-flickr"></i>
					</a>
				<?php } ?>
				</div>
			</div>
			</table>
			<div class="mt-2 redes2-responsive">
		<div class="col-12 align-self-center ">
			<?php if($this->infopage->info_pagina_whatsapp) {?>
			  <?php $whatsapp = intval(preg_replace('/[^0-9]+/', '', $this->infopage->info_pagina_whatsapp), 10);  ?>
			  <a href="https://api.whatsapp.com/send?phone=<?php echo $whatsapp; ?>" target="_blank" class="red mr-4" >
				  <i class="fab fa-whatsapp mr-2"></i>
				  <span><?php echo $this->infopage->info_pagina_whatsapp ?></span>
			  </a>
			  </div>
			  <div class="col-12 align-self-center">
		  <?php } ?>
		  <?php if($this->infopage->info_pagina_correos_contacto) {?>
		<a href="mailto:<?php echo $this->infopage->info_pagina_correos_contacto; ?>" target="_blank" class="red"> <i class="fas fa-envelope mr-2"></i><span><?php echo $this->infopage->info_pagina_correos_contacto; ?></span></a>
		  <?php } ?>
		  </div>	
			</div>
			</div>
