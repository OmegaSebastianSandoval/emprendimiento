<style type="text/css">

body{

}
</style>


<div class="container">
    <div class="row">
        <div class="col-12 titulo-contact">
            <br><h2 class="contact">Zona privada</h2>
        </div>
		<div class="col-12 text-right">
                    <i class="fas fa-user" style="margin-right: 5px;"></i> Bienvenido, <?php echo $this->socio->socio_nombre; ?> <a href="/page/zonaprivada/logout" class="btn btn-sm btn-cafe margen_salir">Salir</a>
		</div>
        <div class="col-12 text-center">
            <br>
            <img src="/corte/post-mayo-22.jpg" class="responsive-img">
        </div>

    </div>
</div>

