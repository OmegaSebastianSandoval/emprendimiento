<div class="entretenimiento">
<?php echo $this->contenido; ?>
</div>